//
//  ViewState.swift
//  MyMoviesCollection
//
//  Created by Filipe Merli on 03/04/20.
//  Copyright © 2020 Filipe Merli. All rights reserved.
//

import Foundation

enum ViewState {
    case loading
    case empty
    case loaded
}
